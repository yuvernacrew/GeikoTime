$(function(){
    setTimeout(function(){
        $('.login-container').fadeIn(500);
    },1000);
})
